using UnityEngine;

public class EnemyController : MonoBehaviour

{
    Vector2 movement;
    public float enemySpeed;
    public Rigidbody2D enemyRb;

    public Transform[] enemyMovementPoint;
    public Transform actualObjective;
    public float detectionRadius = 0.5f;

    public Animator enemyAnimator;
    private bool isFacingRight = true;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        enemyRb = GetComponent<Rigidbody2D>();
        enemyAnimator = GetComponent<Animator>();
        actualObjective = enemyMovementPoint[0];
       
    }

    // Update is called once per frame
    void Update()
    {
        float distanceToObjective = Vector2.Distance(transform.position, actualObjective.position);

        if (distanceToObjective < detectionRadius)
        {
            if (actualObjective == enemyMovementPoint[0])
            {
                actualObjective = enemyMovementPoint[1];
            }
            else if (actualObjective == enemyMovementPoint[1])
            {
                actualObjective = enemyMovementPoint[0];
            }
        }

        Vector2 direction = (actualObjective.position - transform.position).normalized;

        int roundedDirection = Mathf.RoundToInt(direction.x);
        movement = new Vector2(roundedDirection, 0);
        enemyRb.MovePosition(enemyRb.position + movement * enemySpeed * Time.deltaTime);

        if (roundedDirection > 0 && !isFacingRight)
        {
            Flip();
        }
        else if (roundedDirection < 0 && isFacingRight)
        {
            Flip();
        } 

        enemyAnimator.SetFloat("Direccion", roundedDirection);
    }

    public void Flip()
    {
        isFacingRight = !isFacingRight;

        Vector3 localScale = transform.localScale;
        localScale.x *= -1f;
        transform.localScale = localScale;
    }

}

