using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class DarioController : MonoBehaviour
{
    public float speed;
    public float direction;
    public Rigidbody2D rb;

    [SerializeField] private float jumpForce;
    public bool canJump;

    [SerializeField] private Transform GroundCheckD;
    [SerializeField] private float groundCheckRadius;
    [SerializeField] private LayerMask groundLayer;

    public GameObject Hongo;
    public GameObject Flag;
    [SerializeField] private string Tilemap3;
    [SerializeField] private float size = 0f;

    [SerializeField] private LayerMask mudlayer;
    [SerializeField] private Color mudcolor = Color.red;
    private SpriteRenderer spriteRenderer;
    private Color originalColor;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        originalColor = spriteRenderer.color;
    }

    // Update is called once per frame
    void Update()
    {
        canJump = Physics2D.OverlapCircle(GroundCheckD.position, groundCheckRadius, groundLayer);

        rb.AddForce(new Vector2(direction * speed, 0f));
    }

    public void Move(InputAction.CallbackContext context)
    {
        direction = context.ReadValue<Vector2>().x;
    }

    public void Jump(InputAction.CallbackContext context)
    {
        if (context.performed && canJump)
        {
            rb.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse);
        }
    }

    public void OnTriggerStay2D(Collider2D collision)
    {
        if(spriteRenderer != null && ((mudlayer.value & (1 << collision.gameObject.layer)) != 0))
        {
            spriteRenderer.color = originalColor;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Hongo"))
        {
            collision.gameObject.SetActive(false);
            transform.localScale = transform.localScale * size;
        }

        else if (collision.gameObject.CompareTag("Flag"))
        {
            if (Flag != null) Flag.SetActive(false);

            if (!string.IsNullOrEmpty(Tilemap3))
            {
                SceneManager.LoadScene(Tilemap3);
            }
            else
            {
                Debug.LogWarning("Tilemap3 no est� configurado. Asigna SceneAsset en el inspector o configura el nombre de la escena.");
            }
        }
    }
}

