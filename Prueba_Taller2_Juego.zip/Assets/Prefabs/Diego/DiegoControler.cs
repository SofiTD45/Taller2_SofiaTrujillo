using JetBrains.Annotations;
using NUnit.Framework.Interfaces;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class DiegoControler : MonoBehaviour

{
    public float speed;
    public float direction;
    public Rigidbody2D rb;

    public Animator playerAnimator;
    private bool isFacingRight;

    public float jumpForce;
    public bool canJump;

    public Transform groundCheck;
    public float groundCheckRadius;
    public LayerMask groundLayer;

    public GameObject Key;
    public GameObject Door;
    public GameObject Flag;
    public string Tilemap2;

    [Tooltip("Health Player")]
    public float health;
    [SerializeField] private float maxHealth;

    public float hitTime;
    public float hitForce;
    public bool hitForceRight;

    public TextMeshProUGUI healthText;

    public AudioClip hitAudioClip;
    public AudioSource hitAudioSource;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerAnimator = GetComponent<Animator>();

        isFacingRight = true;
        health = maxHealth;

        healthText.text = $"Health: {health}/{maxHealth}";

    }

    // Update is called once per frame
    void Update()
    {
        playerAnimator.SetFloat("Direccion", direction);

        if (hitTime <= 0)
        {
            rb.linearVelocity = new Vector2(direction * speed, rb.linearVelocity.y);
        }
        else
        {
            if (hitForceRight)
            {
                rb.linearVelocity = new Vector2(-hitForce, hitForce);
            }
            else if (!hitForceRight)
            {
                rb.linearVelocity = new Vector2(hitForce, hitForce);
            }

            hitTime -= Time.deltaTime;
        }

        if (!isFacingRight && direction > 0f)
        {
            Flip();
        }
        else if (isFacingRight && direction < 0f)
        {
            Flip();
        }

        /*canJump = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);
        //rb.linearVelocity = new Vector2(direction * speed, rb. linearVelocityY);
        rb.AddForce(new Vector2(direction * speed, 0f));*/
    }

    public void Move(InputAction.CallbackContext context)
    {
        direction = context.ReadValue<Vector2>().x;
    }

    public void Jump(InputAction.CallbackContext context)
    {
        if (context.performed && CanJump())
        {
            rb.linearVelocity = new Vector2(rb.linearVelocityX, jumpForce);
        }
    }

    public bool CanJump()
    {
        bool result = false;
        result = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);
        return result;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Key"))
        {
            collision.gameObject.SetActive(false);
            Door.SetActive(false);
        }

        else if (collision.gameObject.CompareTag("Flag"))
        {
            if (!string.IsNullOrEmpty(Tilemap2))
            {
                SceneManager.LoadScene(Tilemap2);
            }
        }
    }
    public void Flip ()
    {
            isFacingRight = !isFacingRight;

            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
    }
}




