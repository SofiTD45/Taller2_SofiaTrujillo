using System.Drawing;
using System.Globalization;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class TavoController : MonoBehaviour

{
    public float speed;
    public float direction;
    public Rigidbody2D rb;

    [SerializeField] private float jumpForce;
    public bool canJump;

    public GameObject Flag;
    public GameObject Hongo;
    [SerializeField] private string Tilemap1;

    [SerializeField] private Transform GroundCheckT;
    [SerializeField] private float groundCheckRadius;
    [SerializeField] private LayerMask groundLayer;

    private const string JumpForceHongo = "JumpForceHongo";


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        canJump = Physics2D.OverlapCircle(GroundCheckT.position, groundCheckRadius, groundLayer);

        rb.AddForce(new Vector2(direction * speed, 0f));
    }

    public void Move(InputAction.CallbackContext context)
    {
        direction = context.ReadValue<Vector2>().x;
    }

    public void Jump(InputAction.CallbackContext context)
    {
        if (context.performed && canJump)
        {
            rb.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Hongo"))
        {
            collision.gameObject.SetActive(false);
            jumpForce = 10f;
            PlayerPrefs.SetFloat(JumpForceHongo, jumpForce);
            PlayerPrefs.Save();
        }

        if (collision.gameObject.CompareTag("Flag"))
        {
            if (Flag != null) Flag.SetActive(false);

            if (!string.IsNullOrEmpty(Tilemap1))
            {
                SceneManager.LoadScene(Tilemap1);
            }
            else
            {
                Debug.LogWarning("Tilemap1 no est� configurado. Asigna SceneAsset en el inspector o configura el nombre de la escena.");
            }
        }
    }
}
